#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <dirent.h>
#include <inttypes.h>
#include <sys/time.h>
#include <stdbool.h>
#include <pthread.h>
#include <sys/ioctl.h>
#include "math.h"
#include "hps_0.h"
#include  "./OV7670/ov5640.h"
#include <linux/fb.h>
#include <pthread.h>

#include "stdio.h"
#include "sys/types.h"
#include "sys/socket.h"
#include "sys/un.h"
#define UNIX_DOMAIN "/mnt/UNIX.domain"
#define UNIX_DOMAIN2 "/mnt/UNIX2.domain"

#define MY_CDEV_MAGIC 'k'
#define MY_CDEV_CMD  _IO(MY_CDEV_MAGIC,0x1a)
#define MY_CDEV_CMD_READ  _IOR(MY_CDEV_MAGIC,0x1b,int)
#define DEVICE_MAJOR 205


#define HW_REGS_BASE (ALT_STM_OFST )
#define HW_REGS_SPAN (0x04000000 )
#define HW_REGS_MASK (HW_REGS_SPAN - 1 )
#define BMP_WIDTH 640
#define BMP_HEIGHT 480
#define WRITE_COUNT_PILXEL 2
#define BMP_COUNT_PILXEL 3
#define BUFFER_SIZE BMP_WIDTH*BMP_HEIGHT*2
#define BMP_BUFFER_SIZE BMP_WIDTH*BMP_HEIGHT*BMP_COUNT_PILXEL
#define N_SIGNAL 20

volatile unsigned long *h2p_dvp_capture_addr = NULL;
volatile unsigned long *h2p_uart_addr = NULL;
volatile unsigned long *h2p_oc_iic_0_addr = NULL;
volatile unsigned long *h2p_dipsw_addr = NULL;
volatile unsigned long *h2p_pwm0_addr = NULL;
volatile unsigned long *h2p_pwm1_addr = NULL;
volatile unsigned long *h2p_pwm2_addr = NULL;
volatile unsigned long *h2p_pwmlsj0_addr = NULL;
volatile unsigned long *h2p_pwmlsj1_addr = NULL;
volatile unsigned long *h2p_pwmlsj2_addr = NULL;
volatile unsigned long *h2p_pio0_output_addr=NULL;
volatile unsigned long *h2p_ADC_LTC2308_ly_addr=NULL;
volatile unsigned long *h2p_pio_timel_addr=NULL;
volatile unsigned long *h2p_pio_timeh_addr=NULL;//
volatile unsigned long *h2p_pio_led_addr=NULL;
volatile unsigned long *h2p_uart_gprs_addr=NULL;
volatile unsigned long *uart_0_virtual_base = NULL;	//uart_0�����ַ


struct  GradeTime//�����߳�2���߳�3ͨ�ţ��߳�2ÿ0.25���ӷ���һ����Ҷ��������Ҷ�ȼ����������ȼ���ʱ��д���û����塣
{
	int grade[N_SIGNAL];
	unsigned int time[N_SIGNAL];
};
struct GradeTime gradetime;
int GRADE;
//char shuzi[10];
//unsigned int cnt=0;



#define ALT_UART_BASE UART_0_BASE
int capture_init(void)
{
	int fd;
	unsigned long dma_base;
	fd = open("/dev/hbmy_cmos_cap", O_RDWR);
	if (fd == 1) {
		perror("open error\n");
		exit(-1);
	}
	ioctl(fd,MY_CDEV_CMD,&dma_base);

	printf("dma_base is %ld\n",dma_base);
	h2p_dvp_capture_addr[1] = 640*480*2;	//д�벶������ݳ���
	h2p_dvp_capture_addr[2] = dma_base;		//ָ��ͼ��洢��λ�ã�ָ�������������DMAָ��Ĵ洢�����׵�ַ
	h2p_dvp_capture_addr[0] = 1;			//ʹ��ͼ�񲶻�
	return fd;
}
//-----------------  ��ʼ����������������ַָ��  -------------------------//
int fpga_ip_init()
{
	int fd;
	void *lw_axi_virtual_base;
	/*��ʼϵͳ��ʼ��*/
	printf("start app\n");
	if ((fd = open("/dev/mem", ( O_RDWR | O_SYNC))) == -1)
	{
		printf("ERROR: could not open \"/dev/mem\"...\n");
		return (1);
	}
	lw_axi_virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE),MAP_SHARED, fd, HW_REGS_BASE);
	if (lw_axi_virtual_base == MAP_FAILED)
	{
		printf("ERROR: mmap() failed...\n");
		close(fd);
		return (1);
	}

	h2p_dvp_capture_addr = (lw_axi_virtual_base + ((unsigned long) ( ALT_LWFPGASLVS_OFST + DVP_CAP_BASE) & (unsigned long) ( HW_REGS_MASK)));
	h2p_uart_addr = (lw_axi_virtual_base + ((unsigned long) ( ALT_LWFPGASLVS_OFST + ALT_UART_BASE) & (unsigned long) ( HW_REGS_MASK)));
	h2p_oc_iic_0_addr = (lw_axi_virtual_base + ((unsigned long) ( ALT_LWFPGASLVS_OFST + OC_IIC_0_BASE) & (unsigned long) ( HW_REGS_MASK)));
	h2p_dipsw_addr = (lw_axi_virtual_base + ((unsigned long) ( ALT_LWFPGASLVS_OFST + DIPSW_PIO_BASE) & (unsigned long) ( HW_REGS_MASK)));
	h2p_pwmlsj0_addr = (lw_axi_virtual_base + ((unsigned long) ( ALT_LWFPGASLVS_OFST + LSJ_PWM0_BASE) & (unsigned long) ( HW_REGS_MASK)));
	h2p_pwmlsj1_addr = (lw_axi_virtual_base + ((unsigned long) ( ALT_LWFPGASLVS_OFST + LSJ_PWM1_BASE) & (unsigned long) ( HW_REGS_MASK)));
	h2p_pwmlsj2_addr = (lw_axi_virtual_base + ((unsigned long) ( ALT_LWFPGASLVS_OFST + LSJ_PWM2_BASE) & (unsigned long) ( HW_REGS_MASK)));
	h2p_pio0_output_addr = (lw_axi_virtual_base + ((unsigned long) ( ALT_LWFPGASLVS_OFST + PIO_0_BASE) & (unsigned long) ( HW_REGS_MASK)));
	h2p_ADC_LTC2308_ly_addr = (lw_axi_virtual_base + ((unsigned long) ( ALT_LWFPGASLVS_OFST + ADC_LTC2308_0_BASE) & (unsigned long) ( HW_REGS_MASK)));
	h2p_pio_timel_addr = (lw_axi_virtual_base + ((unsigned long) ( ALT_LWFPGASLVS_OFST + PIO_TIMEL_BASE) & (unsigned long) ( HW_REGS_MASK)));
	h2p_pio_timeh_addr = (lw_axi_virtual_base + ((unsigned long) ( ALT_LWFPGASLVS_OFST + PIO_TIMEH_BASE) & (unsigned long) ( HW_REGS_MASK)));
	h2p_pio_led_addr = (lw_axi_virtual_base + ((unsigned long) ( ALT_LWFPGASLVS_OFST + LED_PIO_BASE) & (unsigned long) ( HW_REGS_MASK)));
	h2p_uart_gprs_addr = (lw_axi_virtual_base + ((unsigned long) ( ALT_LWFPGASLVS_OFST + UART_1_BASE) & (unsigned long) ( HW_REGS_MASK)));
	uart_0_virtual_base = (lw_axi_virtual_base+ ((unsigned long) ( ALT_LWFPGASLVS_OFST + UART_0_BASE)& (unsigned long) ( HW_REGS_MASK)));
	return fd;//LED_PIO_BASE
}

typedef struct fbdev{
    int fdfd; //open "dev/fb0"
    struct fb_var_screeninfo vinfo;
    struct fb_fix_screeninfo finfo;
    long int screensize;
    char *map_fb;
}FBDEV;

void init_dev(FBDEV *dev)
{
    FBDEV *fr_dev=dev;
    fr_dev->fdfd=open("/dev/fb0",O_RDWR);
    printf("the framebuffer device was opended successfully.\n");
    ioctl(fr_dev->fdfd,FBIOGET_FSCREENINFO,&(fr_dev->finfo)); //��ȡ �̶�����
    ioctl(fr_dev->fdfd,FBIOGET_VSCREENINFO,&(fr_dev->vinfo)); //��ȡ�ɱ����
    fr_dev->screensize=fr_dev->vinfo.xres*fr_dev->vinfo.yres*fr_dev->vinfo.bits_per_pixel/8;
    fr_dev->map_fb=(char *)mmap(NULL,fr_dev->screensize,PROT_READ|PROT_WRITE,MAP_SHARED,fr_dev->fdfd,0);
    printf("init_dev successfully.\n");
}

void draw_pix(FBDEV *dev,int x,int y, unsigned short rgb) //(x.y) ������
{
    FBDEV *fr_dev=dev;
    int *xx=&x;
    int *yy=&y;
    unsigned char r,g,b;
    unsigned int rgb24;
    long int location=0;
    location=(*xx+fr_dev->vinfo.xoffset)*(fr_dev->vinfo.bits_per_pixel/8)+(*yy+fr_dev->vinfo.yoffset)*fr_dev->finfo.line_length;
    r = (rgb & 0xf800) >> 11;
    g = (rgb & 0x07e0) >> 5;
    b = rgb & 0x1f;
    rgb24 = ((r<<3<<16) | (g << 2 << 8) | (b << 3));
    *((unsigned int *)(fr_dev->map_fb+location))=rgb24;
}

void draw_pic(FBDEV *dev,int x1,int y1,int x2,int y2,unsigned short *p)
{
    FBDEV *fr_dev=dev;
    int *xx1=&x1;
    int *yy1=&y1;
    int *xx2=&x2;
    int *yy2=&y2;
    int i=0,j=0;
    for(j=*yy1;j<*yy2;j++) //ע�� ����Ҫ xx1 < xx2
        for(i=*xx1;i<*xx2;i++)
        {
    		draw_pix(fr_dev,i,j,*p);
    		p++;
        }
}

//���ƵĻҶȴ���
void huiduchuli(unsigned short *p,unsigned short *white_ly)
{
	unsigned int i,j;
	unsigned char r,g,b;
	for (i = 0; i < 480; i++)
		{
			for (j = 0; j < 640; j++)
			{
			  r = (*p & 0xf800) >> 11; //ȡ*p��11��15bit����5bit�����ֵΪ32
			  g = (*p & 0x07e0) >> 5;  //ȡ*p��5��10bit����6bit�����ֵΪ64
			  b = *p & 0x1f;		   //ȡ*p��0��4bit����5bit�����ֵΪ32
              r =  r*0.299 ;
              g=   g*0.587;
              b =  b*0.114 ;
			  *white_ly = ((r<<11) | (g <<5) | (b))+0.5;//�Ѱ�ɫ��ɺ�ɫ���ָ�����顣
			  p++;	//ͼƬת����һ�����ص㣬��ָ���ַ��һ
			  white_ly++;
			}
		}
}



//ͨ����˸��չʾ�Ƿ�գ��
unsigned short led_flash(unsigned short *p,unsigned int x,unsigned int y)
{
	unsigned int i,j;
	unsigned char r,g,b;
	unsigned int cnt=0;
	static int n,m;
	for (i = 0; i < 480; i++)
		{
			for (j = 0; j < 640; j++)
			{
		      r = (*p & 0xf800) >> 11; //ȡ*p��11��15bit����5bit�����ֵΪ32
			  g = (*p & 0x07e0) >> 5;  //ȡ*p��5��10bit����6bit�����ֵΪ64
			  b = *p & 0x1f;		   //ȡ*p��0��4bit����5bit�����ֵΪ32
			  if((i==x)&&(j==y))
			  {
				  if((r==0)&&(g==0)&&(b==0))
				  {
					 m=n;
					 n=1;
				  }
				  else
				  {
					  m=n;
					  n=0;
				  }
			  }
			  p++;	//ͼƬת����һ�����ص㣬��ָ���ַ��һ
		    }
		}
	if(n==1&&m==1)
		cnt=1;
	return cnt;
}

//�Թ涨����Ķ�ֵ��
void erzhihua(unsigned short *p,unsigned int x,unsigned int y,unsigned int l)
{
	unsigned int i,j;
	unsigned char r,g,b;
	x=x+(3*l/8);
	y=y+(3*l/8);
	l=l/4;
	for (i = 0; i < 480; i++)
		{
			for (j = 0; j <640; j++)
			{
			  r = (*p & 0xf800) >> 11; //ȡ*p��11��15bit����5bit�����ֵΪ32
			  g = (*p & 0x07e0) >> 5;  //ȡ*p��5��10bit����6bit�����ֵΪ64
			  b = *p & 0x1f;		   //ȡ*p��0��4bit����5bit�����ֵΪ32
			  if((j>x)&&(j<x+l)&&(i>y)&&(i<y+l))
			  {

				  if((r>10)||(g>11)||(b>12))
				  {
					r =255 ;
					g= 255 ;
					b =255 ;
				  }
				  else
				  {
					r =0 ;
					g= 0 ;
					b =0 ;
				  }
			  }
			  *p = ((r<<11) | (g <<5) | (b));//�Ѱ�ɫ��ɺ�ɫ���ָ�����顣
			  p++;	//ͼƬת����һ�����ص㣬��ָ���ַ��һ
			}
		}
}


void draw_pic_gh(FBDEV *dev,int rec_buf[])
{
	FBDEV *fr_dev=dev;
    int  i=0;
    int l,x,y,x1,y1,x2,y2;
    unsigned char r,g,b;
    int k=0;
	for(i=1;i<100;i++)
	{
		if(rec_buf[i]%10000==0)
		{
			l=rec_buf[i+1];
			x=rec_buf[i+2];
			y=rec_buf[i+3];
			r = 0;g = 0;b = 255;
			x1=x;
			y1=y;
			x2=x1+l;
			y2=y1+l;
		    int *xx1=&x1;
		    int *yy1=&y1;
		    int *xx2=&x2;
		    int *yy2=&y2;
			int n=0,m=0;
				for(n=*yy1;n<=*yy2;n++) //ע�� ����Ҫ xx1 < xx2
					for(m=*xx1;m<=*xx2;m++)
					{
						if(((m==*xx1)&&(n>=*yy1&&n<=*yy2))||((m==*xx2)&&(n>=*yy1&&n<=*yy2))||((n==*yy1)&&(m>=*xx1&&m<=*xx2))||((n==*yy2)&&(m>=*xx1&&m<=*xx2)))
						{
							draw_pix2(fr_dev,m,n,r,g,b);
						}
					}
		}
		else
		{
			if(rec_buf[i]>10000)
			{
				l=rec_buf[i+1];
				x1=rec_buf[i+2]+x;
				y1=rec_buf[i+3]+y;
				r = 0;g = 255;b = 0;
				x2=x1+l;
				y2=y1+l;
				int *xx1=&x1;
				int *yy1=&y1;
				int *xx2=&x2;
				int *yy2=&y2;
				int n=0,m=0;
					for(n=*yy1;n<=*yy2;n++) //ע�� ����Ҫ xx1 < xx2
						for(m=*xx1;m<=*xx2;m++)
						{
							if(((m==*xx1)&&(n>=*yy1&&n<=*yy2))||((m==*xx2)&&(n>=*yy1&&n<=*yy2))||((n==*yy1)&&(m>=*xx1&&m<=*xx2))||((n==*yy2)&&(m>=*xx1&&m<=*xx2)))
								{
								  draw_pix2(fr_dev,m,n,r,g,b);
								}
						}
			}
		}
			if(rec_buf[i]==0)
		    {
		    	i=100;
		    }
	}
}
void draw_pix2(FBDEV *dev,int x,int y,unsigned char r,unsigned char g,unsigned char b) //(x.y) ������
{
    FBDEV *fr_dev=dev;
    int *xx=&x;
    int *yy=&y;
    unsigned int rgb24;
    long int location=0;
    location=(*xx+fr_dev->vinfo.xoffset)*(fr_dev->vinfo.bits_per_pixel/8)+(*yy+fr_dev->vinfo.yoffset)*fr_dev->finfo.line_length;
    rgb24 = ((r<<3<<16) | (g << 2 << 8) | (b << 3));
    *((unsigned int *)(fr_dev->map_fb+location))=rgb24;
}

pthread_t ntid1;
pthread_t ntid2;
pthread_t ntid3;
pthread_t ntid4;
