	#include<opencv2/core/core.hpp>
	#include<opencv2/highgui/highgui.hpp>
	#include<opencv2/opencv.hpp>
	#include<iostream>

	#include "iostream"
	#include "string.h"
	#include "fstream"

	#include "stdio.h"
	#include <opencv2/opencv.hpp>
	#include <string>
	
	#include "sys/types.h"
	#include "sys/socket.h"
	#include "sys/un.h"
	#include "unistd.h"
	#define UNIX_DOMAIN "/mnt/UNIX.domain"

#define PIC_WIDTH 640
#define PIC_HIGHT 480
#define PIC_Pix_Num (PIC_WIDTH*PIC_HIGHT)

#define img_size_4th (PIC_WIDTH*PIC_HIGHT/4)	//soc每次传递的像素的个数
	
#define img_size 76800

	using namespace std;
	using namespace cv;

		int img_number=0;

	class ReadAndWriteFile
	{

	public:
		bool ReadFile2Array(string fileName, int* readData, int* Datalength);
		Mat Array2Mat(int* a, const char* str);
		int RGB565ToRGB888(int n565Color);
		int RGBTOGray(int n565Color);
	};

	Mat ReadAndWriteFile::Array2Mat(int* a, const char* str)
	{
		Mat M(480, 640, CV_8UC1, a);
		for (int i = 0; i < M.rows; ++i)
		{
		        uchar* p = M.ptr<uchar>(i);
		        for (int j = 0; j < M.cols; ++j)
		                p[j] = a[i * 640 + j];
		}
//		if(img_number==5)
//			imwrite(str, M);
		return M;
	}
	int ReadAndWriteFile::RGB565ToRGB888(int n565Color)
	{
		int n888Color = 0;      
		unsigned char cRed   = (n565Color & 0xF800)     >>    8;
		unsigned char cGreen = (n565Color & 0x07E0)     >>    4;
		unsigned char cBlue  = (n565Color & 0x001F)     <<    3;

		n888Color = (cRed * 299 + cGreen * 587 + cBlue * 114 + 500) / 1000;
		return n888Color;
	}

int main()
{
	  int ReadDate[640 * 480];
	  socklen_t clt_addr_len;
	  int listen_fd;
	  int com_fd;
	  int ret;
	  int i,j;
	  int k=0;
	  static short int recv_buf[img_size_4th];
	  int snd_buf[100]={0};
	  int len;
          int num=0;
	  int face_num=0;
	  int eyes_num=0;
	  int snd_buf_pos=0;
	  struct sockaddr_un clt_addr;
	  struct sockaddr_un srv_addr;		

			cv::CascadeClassifier face_cascade;
			char* face_cascade_name = ("haarcascade_frontalface_default.xml");

			cv::CascadeClassifier eyes_cascade;
			char* eyes_cascade_name  = ("haarcascade_eye.xml");

	
			if (!face_cascade.load(face_cascade_name))
				printf("--(!)Error loading face cascade\n");
			else
				printf("load finish\n");

			if (!eyes_cascade.load(eyes_cascade_name))			
				printf("--(!)Error loading eyes cascade\n");
			else
				printf("load finish\n");	

	  listen_fd=socket(PF_UNIX,SOCK_STREAM,0);
	  if(listen_fd<0)
	  {
		perror("cannot create communication socket");
		return 1;
	  }

	  srv_addr.sun_family=AF_UNIX;
	  strncpy(srv_addr.sun_path,UNIX_DOMAIN,sizeof(srv_addr.sun_path)-1);
	  unlink(UNIX_DOMAIN);

	  ret=bind(listen_fd,(struct sockaddr*)&srv_addr,sizeof(srv_addr));
	  if(ret==-1)
	  {
		perror("cannot bind server socket");
		close(listen_fd);
		unlink(UNIX_DOMAIN);
		return 1;
	  }

	  ret=listen(listen_fd,1);
	  if(ret==-1)
	  {
		perror("cannot listen the client connect request");
		close(listen_fd);
		unlink(UNIX_DOMAIN);
		return 1;
	  }


	  com_fd=accept(listen_fd,NULL,NULL);
	  if(com_fd<0)
	  {
		perror("cannot accept client connect request");
		close(listen_fd);
		unlink(UNIX_DOMAIN);
		return 1;
	  }
		

	  while(1)
	  {
		for(i=0;i<4;i++)
		{
		  memset(recv_buf,0,2*img_size_4th);
		  num=recv(com_fd,recv_buf,img_size_4th*sizeof(short int),MSG_WAITALL);//change read to recv (and add MSG_WAITALL)
		  printf("num=%d\n",num);
		 
		  for(k=0;k<img_size_4th;k++)
		  {
			ReadDate[i*img_size_4th+k]=(int)recv_buf[k];
		  }
//		  snd_buf[i]=i+1;
//		  write(com_fd,snd_buf,sizeof(snd_buf));
		}
		img_number++;

		ReadAndWriteFile rd;

		string fileName;
		string outfileName;
		outfileName = "rectangle_place.txt";
		ofstream outFile;

		for (int i = 0; i < 307200; i++)
		{
			ReadDate[i] = rd.RGB565ToRGB888(ReadDate[i]);
		}

		Mat img_gray_detect = rd.Array2Mat(ReadDate, "eye.jpg");

		std::vector<cv::Rect>   faces;
		face_cascade.detectMultiScale(img_gray_detect, faces, 1.3, 5, 0 | cv::CASCADE_SCALE_IMAGE, cv::Size(30, 30));
	
		if(faces.size()==0)
			cout << "no face" <<endl;
		else
		{
				outFile.open(outfileName);

				if (!outFile.is_open())
				{
					std::cout << "打开文件失败 \n" << endl;
				}
		}

                //jian ce niande shumu 
		
		memset(snd_buf,0,sizeof(snd_buf));

                face_num=faces.size();
                snd_buf_pos=0;
		snd_buf[snd_buf_pos]=face_num;

		for (int i = 0; i < face_num; i++)
		{
			cout << "faces number :"<< i+1 <<endl;
			cout << faces[i]<<endl;
				

			cv::Mat faceROI = img_gray_detect(faces[i]);

			std::vector<cv::Rect> eyes;
			eyes_cascade.detectMultiScale(faceROI, eyes, 1.1, 2, 0 | cv::CASCADE_SCALE_IMAGE, cv::Size(30, 30));
			eyes_num=eyes.size();
			// fa nian 
			snd_buf_pos++;
			snd_buf[snd_buf_pos]=10000*(i+1);
			snd_buf_pos++;
			snd_buf[snd_buf_pos]=faces[i].width;
			snd_buf_pos++;
			snd_buf[snd_buf_pos]=faces[i].x;
			snd_buf_pos++;
			snd_buf[snd_buf_pos]=faces[i].y;
			//fa eye
			eyes_num=eyes.size();
			for(j = 0; j < eyes_num; j++)
			{
				snd_buf_pos++;
				snd_buf[snd_buf_pos]=10000*(i+1)+1+j;
				snd_buf_pos++;
				snd_buf[snd_buf_pos]=eyes[j].width;
				snd_buf_pos++;
				snd_buf[snd_buf_pos]=eyes[j].x;
				snd_buf_pos++;
				snd_buf[snd_buf_pos]=eyes[j].y;
			}
				

		
			if(eyes_num==0)
				cout << "no eyes" <<endl;			

			for(int j = 0; j < eyes_num; j++)
			{
			        cout << "eyes number :"<< j+1 <<endl;
			        cout << eyes[j]<<endl;

			}

		}
		write(com_fd,snd_buf,sizeof(snd_buf));
	  }
		close(com_fd);
		  close(listen_fd);
		 unlink(UNIX_DOMAIN);


	    return 0;
}

